






<html xmlns="http://www.w3.org/1999/xhtml">
 <head>


<script data-ad-client="ca-pub-1504422339942672" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-167183847-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-167183847-1');
</script>

      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <link rel="shortcut icon" href="" type="image/x-icon" />
      <title>Satta leak number | Satta king leak number | gali desawar leak | satta leak | satta leak jodi | desawar leak number </title>
      <meta name="Description" content="satta leak number, satta king leak, satta king leak no, satta leak no, gali desawar leak, satta leak jodi, desawar leak number " />
      <meta name="keywords" content="satta leak number, satta king leak, satta king leak no, satta leak no, gali desawar leak, satta leak jodi, desawar leak number " />
      <meta name="viewport" content="width=device-width" />
	  <meta name="author" content="Satta king">
	  <link rel="stylesheet" href="css/background.css">
	  <link rel="stylesheet" href="css/style.css?id=237">
      <link rel="stylesheet" href="css/bootstrap.min.css">
	  <link rel="icon" href="images/fav.png" type="image/gif" sizes="16x16">
	  <meta http-equiv="Content-Security-Policy" content="script-src * 'unsafe-inline' *.jivosite.com; connect-src *.jivosite.com">
	  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-167183847-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-167183847-1');
</script>     </head>
   <body>
     
<table class="nav_tbl">
<tr>
<td style="width:25%"><a href="index.php">HOME</a></td>
<td style="width:25%"><a href="all-game-record-chart.php">CHART</a></td>
<td style="width:25%"><a href="satta-king-fast-result.php">RESULTS</a></td>
<td style="width:25%"><a title="satta leak number" href="satta-leak-number.php">LEAK</a></td>
</tr>
</table>         
             <marquee class="king_scroll"> Satta King Result, SattaKing, Satta, Satta.Com, Satta Com, Gali Result, Satta News, Today Satta Result, Live Satta King, Satta Aaj Ka Satta Result, Gali Result Today</marquee>
         
         <div class="enter1">
          <h1>SATTA KING GAME RECORD CHART</h1>
		  <a href="index.php">WWW.SATTA-KINGZ.IN</a>
         </div>
<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 10px; border-radius: 10px; text-align: center;">
<font color="black" size="2">Www.Satta-Kingz.In</font><br/>
<font style="color:red; font-size:14px">गली , दिशावर , गाजियाबाद FIX SINGLE JODI लेने के लिए सम्पर्क करें गेम 101% फाइनल पास होगी  जिनकी गेम नही पास होती हमसे जुडे  
हम पास कराएगें </font><br>
<font style="color:blue;font-size:15px">MANOJ TYAGI</font><br>
<font style="color:red;font-size:20px">08979381970</font><br>
<a href="tel:+918979381970" style="font-size:10px"><button style="color:red">CLICK FOR CALL</button></a>
<font style="color:green;font-size:12px"><br>AVAILABLE ON WHATS APP</font>
</div>
<!--<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 10px; border-radius: 10px; text-align: center;">
<font color="black" size="2">Www.Satta-Kingz.In</font><br/>
<font style="color:red; font-size:14px">फ्री फ्री फ्री आज गेम मिलेगा बिल्कुल फ्री गेम कंपनी से सीधा लीक होगा मोटा खेलने वाले ही मैसेज करें गेम 4 जोड़ी में रहेगा गली और दिसावर पास होने के बाद में ओन्ली 15000 रुपए देने होंगे</font><br>
<font style="color:blue;font-size:15px">Goutam Rajput - 7528912423</font><br>
<a href="tel:+917528912423" style="font-size:10px"><button style="color:red">CLICK FOR CALL</button></a>
<font style="color:green;font-size:11px"><br>AVAILABLE ON WHATS APP</font>
</div>-->

<!--<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 10px; border-radius: 10px; text-align: center;">
<font color="black" size="2">Www.Satta-Kingz.In</font><br/>
<font style="color:red; font-size:14px">क्या आपको कभी पक्का नंबर नही मिला एडवांस देने के बाद भी क्या आपको दिए हुए एडवांस पैसे लेके भागा है कोई । ऐसे धोकेबाज लोगो से बचो और हमसे संपर्क करो । हम देंगे आपको गली दिसावर फरीदाबाद ग़ाज़ियाबाद में लीक नंबर जो 101% पास होगा कॉल करे</font><br>
<font style="color:blue;font-size:15px">Dev Sharma - 6399056183</font><br>
<a href="tel:+916399056183" style="font-size:10px"><button style="color:red">CLICK FOR CALL</button></a>
<font style="color:green;font-size:11px"><br>AVAILABLE ON WHATS APP</font>
</div>-->






	  
<div align="center">	  
 <div class="liveresult">
               
			   <script type="text/javascript">
                var tmonth = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
                function GetClock(){
                var d = new Date();
                var nmonth = d.getMonth(), ndate = d.getDate(), nyear = d.getFullYear();
                var nhour = d.getHours(), nmin = d.getMinutes(), nsec = d.getSeconds(), ap;
                if (nhour == 0){ap = " AM"; nhour = 12; }
                else if (nhour < 12){ap = " AM"; }
                else if (nhour == 12){ap = " PM"; }
                else if (nhour > 12){ap = " PM"; nhour -= 12; }

                if (nmin <= 9) nmin = "0" + nmin;
                if (nsec <= 9) nsec = "0" + nsec;
                document.getElementById('clockbox').innerHTML = "" + tmonth[nmonth] + " " + ndate + ", " + nyear + " " + nhour + ":" + nmin + ":" + nsec + ap + "";
                }

                window.onload = function(){
                GetClock();
                setInterval(GetClock, 1000);
                }
            </script> <div class="datetime">
            <div style="color:yellow; font-weight:bold" id="clockbox"></div></div>
			<p style="color:#FFF">हा भाई यही आती हे सबसे पहले खबर रूको और देखो</p>

             	
	<div class="sattaname"><p style="margin:0px">FARIDABAD </p></div>
    <div class="sattaresult"><font>7633</font></div>
	
	             </div>
 
 
 
		 

<div class="container-fluid">
<div class="border row">


 <div class="border col-md-12 col-sm-12 col-xs-12" style="padding: 0 1px 0 1px; border: 1px solid black; background-color:#003300"> 
    <div  align="center"><span><font style="text-transform: uppercase; color:#fff;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">DESAWAR</font></span><br>
<font style="color:yellow">( 05:10 AM )<br>
<font style="font-size:20px"><b style="color:#fff"> { 06 }</font>
<img src="images/arrow.gif" alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:20px; color:#58FACD"> [ <span style="color:#fff">  47 ]</b> 

</font>
</td>
</div> </div>
 

<div class="back1 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">MUMBAI</font><br>
 <font style="color:#000; font-weight:bold">( 11:00 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 59 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back2 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">DL-NCR</font><br>
 <font style="color:#000; font-weight:bold">( 04:00 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 79 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back3 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">SHIV HARI</font><br>
 <font style="color:#000; font-weight:bold">( 05:15 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 38 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back4 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">TULSI</font><br>
 <font style="color:#000; font-weight:bold">( 03:15 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 45 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back5 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">SUPER GURGAON</font><br>
 <font style="color:#000; font-weight:bold">( 10:00 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 76 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back6 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">KAVERI</font><br>
 <font style="color:#000; font-weight:bold">( 09:00 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 52 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back7 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">KUBER</font><br>
 <font style="color:#000; font-weight:bold">( 08:35 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 67 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back8 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">JAIPUR</font><br>
 <font style="color:#000; font-weight:bold">( 05:30 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 96 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back9 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">KALYAN DELHI</font><br>
 <font style="color:#000; font-weight:bold">( 09:30 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 17 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back10 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">DELHI KING</font><br>
 <font style="color:#000; font-weight:bold">( 11:00 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 96 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back11 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">GALI GOLD NEW</font><br>
 <font style="color:#000; font-weight:bold">( 05:30 AM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 30 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [ 62 ] </b></font>
</div> 



<div class="back12 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">NEW DELHI</font><br>
 <font style="color:#000; font-weight:bold">( 04:00 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 62 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back13 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">RAWALPINDI</font><br>
 <font style="color:#000; font-weight:bold">( 02:10 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 95 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back14 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">FARIDABAD </font><br>
 <font style="color:#000; font-weight:bold">( 06:05 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 60 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [ 7633 ] </b></font>
</div> 



<div class="back15 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">GHAZIABAD</font><br>
 <font style="color:#000; font-weight:bold">( 08:15 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 93 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



<div class="back16 col-md-6 col-sm-6 col-xs-6 " style="padding: 3px 1px 3px 1px; border: 1px solid #413a3a;"> 
    <font style="color:red;font-size:17px; font-weight:bold; padding-left:2px; padding-right:2px">GALI</font><br>
 <font style="color:#000; font-weight:bold">( 11:15 PM )<br>
<font style="font-size:16px; color:#000; font-weight:bold">{ 75 }</font>
<img src="images/www.gif" width="20" height="10"  alt="satta king live result | fast live result | satta live result" title="satta live result | satta king live result | satta vip king"></font>
<font style="font-size:16px;color:blue; font-weight:bold"> [  ] </b></font>
</div> 



  </div>
</div>





<table border="1" align="center" width="100%">
   <td align="center" width="50%" class="ONLINE">
      <a title="satta king" href="https://www.satta-kingz.in/">
      <font color="#ffffff">Satta king</font></a> 
   </td>
   <td align="center" width="100%" class="ONLINE">
      <a title="satta king" href="https://www.satta-kingz.in/">
      <font color="#ffffff">Satta King</font></a> 
   </td>
   </a> </td>
</table>

<div class="cht_link"> 
      <a href="satta-king-game-record-chart.php" >SATTA KING RECORDS CHART </a>
   </div>
 <div class="cht_link"> 
      <a href="satta-king-game-record-chart.php" >D-D GALI DISAWAR RECORD CHART</a>
   </div>  
 <div class="cht_link"> 
      <a title="desawar satta record chart 2020" href="desawar-satta-record-chart-2020.php" >DESAWAR RECORD CHART 2020</a>
   </div>    
<div class="cht_link"> 
      <a title="gali satta record chart 2020" href="gali-satta-record-chart-2020.php" > GALI SATTA RECORD CHART 2020  </a>
   </div> 
<div class="cht_link"> 
      <a title="faridabad satta record chart 2020" href="faridabad-satta-record-chart-2020.php" >FARIDABAD SATTA RECORD CHART 2020</a>
   </div>       
<div class="cht_link"> 
      <a title="ghaziabad satta record chart 2020" href="ghaziabad-satta-record-chart-2020.php" >GHAZIABAD SATTA RECORD CHART 2020</a>
   </div>       
 <!--<div class="cht_link"> 
      <a title="taj satta record chart 2020" href="taj-satta-record-chart-2020.php" >TAJ SATTA RECORD CHART 2020</a>
   </div>
   <div class="cht_link"> 
      <a title="UP satta record chart 2020" href="UP-satta-record-chart-2020.php" >UP SATTA RECORD CHART 2020</a>
   </div>
  <div class="cht_link"> 
      <a title="Shri ganesh satta record chart 2020" href="shri-ganesh-satta-record-chart-2020.php" >SHRI GANESH SATTA RECORD CHART 2020</a>
   </div> 
<div class="cht_link"> 
      <a title="delhi King satta record chart 2020" href="delhi-king-satta-record-chart-2020.php" >DELHI KING SATTA RECORD CHART 2020</a>
   </div>   -->         
<div class="cht_link"> 
      <a title="satta king fast result" href="satta-king-fast-result.php" > SATTA KING FAST RESULT </a>
   </div>            

      




<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 5px; border-radius: 10px; text-align: center;">
    <font style="color:#000; font-size:16px">Www.satta-kingz.in</font><br>
<font style="color:red; font-size:15px"> अपनी सट्टा मटका गेम का रिज़ल्ट हमारी वेबसाइट मे डलवाना हो या अपनी गेम बेच कर पैसा कमाना चाहते हो तो कॉल करे </font>
<br><span style="color: brown">*****************</span><br>
<img style="width:30px" src="images/call.png" alt="satta king com satta com सट्टा नंबर सट्टा-किंग सट्टाकिंग सट्टा रिज़ल्ट सट्टा गेम satta king result, satta king online,today satta result, satta.com">
<br><font style="color:blue; font-size:15px">MAX MILLER <br> Phone No.7042553480</font><br>


<a style="font-size:12px" href="tel:+917042553480"><button>CLICK FOR CALL</button></a>
        <br>
		<p style="color:brown; font-size:14px">AVAILABLE ON WHATS APP</p></div>
<div class="footer">
<p>SATTA KINGZ &copy; 2020</p>
<a href="contact.php">Contact</a> | <a href="disclaimer.php">Disclaimer</a> | <a href="sitemap.xml">Sitemap</a>
<script src="//code.jivosite.com/widget/O0KBC3zD5D" async></script>
</div>


      </body>
</html>
