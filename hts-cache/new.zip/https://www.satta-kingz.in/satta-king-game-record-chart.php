






<html xmlns="http://www.w3.org/1999/xhtml">
 <head>


<script data-ad-client="ca-pub-1504422339942672" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>


      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <link rel="shortcut icon" href="" type="image/x-icon" />
      <title>SATTA KING | SATTA RECORD | SATTA KING RECORD | SATTA LIVE RECORD | SATTA KING DARABAR| SATTA KING 2019 | SATTA BAJAR | SATTA KING UP</title>
      <meta name="Description" content="satta king, sattaking, satta king online, satta king 786, satta king result ,satta king record, satta king leak, satta king number, satta king bazzar, satta king UP, सट्टा किंग , gali result, Desawar result, Satta king live "/>
      <meta name="Keywords" content="satta king, sattaking, satta king online, satta king 786, satta king result ,satta king record, satta king leak, satta king number, satta king bazzar, satta king UP,  सट्टा किंग "/>
      <meta name="author" content="Satta king">
	  <meta name="viewport" content="width=device-width" />
	  <link rel="stylesheet" href="css/background.css">
	  <link rel="stylesheet" href="css/style.css?id=237">
      <link rel="stylesheet" href="css/bootstrap.min.css">
	  <link rel="icon" href="images/fav.png" type="image/gif" sizes="16x16">
	  <meta http-equiv="Content-Security-Policy" content="script-src * 'unsafe-inline' *.jivosite.com; connect-src *.jivosite.com">
	  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-167183847-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-167183847-1');
</script>      </head>
   
<table class="nav_tbl">
<tr>
<td style="width:25%"><a href="index.php">HOME</a></td>
<td style="width:25%"><a href="all-game-record-chart.php">CHART</a></td>
<td style="width:25%"><a href="satta-king-fast-result.php">RESULTS</a></td>
<td style="width:25%"><a title="satta leak number" href="satta-leak-number.php">LEAK</a></td>
</tr>
</table>         
             <marquee class="king_scroll"> Satta King Result, SattaKing, Satta, Satta.Com, Satta Com, Gali Result, Satta News, Today Satta Result, Live Satta King, Satta Aaj Ka Satta Result, Gali Result Today</marquee>
         
         <div class="enter1">
          <h1>SATTA KING GAME RECORD CHART</h1>
		  <a href="index.php">WWW.SATTA-KINGZ.IN</a>
         </div>
         
      
      
      





<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 10px; border-radius: 10px; text-align: center;">
<font color="black" size="2">खुशखबरी खुशखबरी खुशखबरी</font><br/>
<font style="color:red; font-size:14px">गेम पास होने के बाद में करनी होगी पेमेंट गेम पास होने के बाद में करनी होगी पेमेंट ओन्ली 4 जोड़ी में रहेगा गेम कंपनी से जो होगा सीधा लिख एक बार विश्वास कर कर देखें बार-बार हमारे पास से गेम लोगे</font><br>
<font style="color:blue;font-size:15px"> ध्रुव देवलिया 8360509293</font><br>
<a href="tel:+918360509293" style="font-size:10px"><button style="color:red">CLICK FOR CALL</button></a>
<font style="color:green;font-size:11px"><br>WhatsApp Available</font>
</div>

<!--<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 10px; border-radius: 10px; text-align: center;">
<font color="black" size="2">खुशखबरी खुशखबरी खुशखबरी</font><br/>
<font style="color:red; font-size:14px"> 
गेम पास होने के बाद में करनी होगी पेमेंट ओन्ली 4 जोड़ी में रहेगा गेम कंपनी से जो होगा सीधा लीक एक बार विश्वास कर कर देखें बार-बार हमारे पास से गेम लोगे</font><br>
<font style="color:blue;font-size:15px">ध्रुव देवलिया - 8360509293</font><br>
<a href="tel:+918360509293" style="font-size:10px"><button style="color:red">CLICK FOR CALL</button></a>
<font style="color:green;font-size:11px"><br>WhatsApp Available</font>
</div>-->

<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 10px; border-radius: 10px; text-align: center;">
<font color="black" size="2">Www.Satta-Kingz.In</font><br/>
<font style="color:red; font-size:14px">गली , दिशावर , गाजियाबाद FIX SINGLE JODI लेने के लिए सम्पर्क करें गेम 101% फाइनल पास होगी  जिनकी गेम नही पास होती हमसे जुडे  
हम पास कराएगें </font><br>
<font style="color:blue;font-size:15px">MANOJ TYAGI</font><br>
<font style="color:red;font-size:20px">08979381970</font><br>
<a href="tel:+918979381970" style="font-size:10px"><button style="color:red">CLICK FOR CALL</button></a>
<font style="color:green;font-size:12px"><br>AVAILABLE ON WHATS APP</font>
</div>
<!--<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 10px; border-radius: 10px; text-align: center;">
<font color="black" size="2">Www.Satta-Kingz.In</font><br/>
<font style="color:red; font-size:14px">फ्री फ्री फ्री आज गेम मिलेगा बिल्कुल फ्री गेम कंपनी से सीधा लीक होगा मोटा खेलने वाले ही मैसेज करें गेम 4 जोड़ी में रहेगा गली और दिसावर पास होने के बाद में ओन्ली 15000 रुपए देने होंगे</font><br>
<font style="color:blue;font-size:15px">Goutam Rajput - 7528912423</font><br>
<a href="tel:+917528912423" style="font-size:10px"><button style="color:red">CLICK FOR CALL</button></a>
<font style="color:green;font-size:11px"><br>AVAILABLE ON WHATS APP</font>
</div>-->

<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 10px; border-radius: 10px; text-align: center;">
<font color="black" size="2">Www.Satta-Kingz.In</font><br/>
<font style="color:red; font-size:14px">गली और देसावर में सिंगल लीक जोड़ी करेगी धमाल। अभी WhatsApp करें और पाए आज का लीक नंबर फ़ोन पर ही डेली लीक रिपोर्ट पास करवाने का चैलेंज करता हूँ  10000% Guarntee से पास जो लॉस में हैं वो जल्द ही कांटेक्ट करें और प्रोफ़िट कमाये</font><br>


<font style="color:blue;font-size:15px">Jatin tyagi 9193496326</font><br>
<a href="tel:+919193496326" style="font-size:10px"><button style="color:red">CLICK FOR CALL</button></a>
<font style="color:green;font-size:11px"><br>AVAILABLE ON WHATS APP</font>
</div>



	  
<div align="center">	  
 <div class="liveresult">
               
			   <script type="text/javascript">
                var tmonth = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
                function GetClock(){
                var d = new Date();
                var nmonth = d.getMonth(), ndate = d.getDate(), nyear = d.getFullYear();
                var nhour = d.getHours(), nmin = d.getMinutes(), nsec = d.getSeconds(), ap;
                if (nhour == 0){ap = " AM"; nhour = 12; }
                else if (nhour < 12){ap = " AM"; }
                else if (nhour == 12){ap = " PM"; }
                else if (nhour > 12){ap = " PM"; nhour -= 12; }

                if (nmin <= 9) nmin = "0" + nmin;
                if (nsec <= 9) nsec = "0" + nsec;
                document.getElementById('clockbox').innerHTML = "" + tmonth[nmonth] + " " + ndate + ", " + nyear + " " + nhour + ":" + nmin + ":" + nsec + ap + "";
                }

                window.onload = function(){
                GetClock();
                setInterval(GetClock, 1000);
                }
            </script> <div class="datetime">
            <div style="color:yellow; font-weight:bold" id="clockbox"></div></div>
			<p style="color:#FFF">हा भाई यही आती हे सबसे पहले खबर रूको और देखो</p>

             	
	<div class="sattaname"><p style="margin:0px">FARIDABAD </p></div>
    <div class="sattaresult"><font>7633</font></div>
	
	             </div>
 
 
 
		 


<!--<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 10px; border-radius: 10px; text-align: center;">
<font color="black" size="2">Www.Satta-Kingz.In</font><br/>
<font style="color:red; font-size:14px">क्या आपको कभी पक्का नंबर नही मिला एडवांस देने के बाद भी क्या आपको दिए हुए एडवांस पैसे लेके भागा है कोई । ऐसे धोकेबाज लोगो से बचो और हमसे संपर्क करो । हम देंगे आपको गली दिसावर फरीदाबाद ग़ाज़ियाबाद में लीक नंबर जो 101% पास होगा कॉल करे</font><br>
<font style="color:blue;font-size:15px">Dev Sharma - 6399056183</font><br>
<a href="tel:+916399056183" style="font-size:10px"><button style="color:red">CLICK FOR CALL</button></a>
<font style="color:green;font-size:11px"><br>AVAILABLE ON WHATS APP</font>
</div>-->



  



 
 <div  class="col-md-12 col-sm-12 col-xs-12" style="padding-top:7px; padding-bottom:0px; text-align:center; background-color:pink; border:2px solid palevioletred; color:#000; font-weight:bold">
				<form class="form-inline" method="post">
                      
                  <select style="width:110px; height:33px;" name="year_select" id="sel1">
				      <option selected value="2020">2020</option>
				  </select>
				
				
    
         <select style="width:110px; height:33px; text-align:center" name="month_select">
		  <option value="01">January</option> 
		  <option value="02">February</option> 
		  <option value="03">March </option> 
		  <option value="04">April</option> 
		  <option value="05">May</option> 
		  <option selected value="06">June</option> 
		  <option value="07">july</option> 
		  <option value="08">August</option> 
		  <option value="09">September</option> 
		  <option value="10">October</option> 
		  <option value="11">November</option> 
		  <option value="12">December</option> 
				</select>
    <button style="background-color:#FFF; height:33px; color:#000; font-weight:bold" type="submit"  class="btn btn-success">Submit</button>
   </form>
  </div>
        
      
	  
   
       <center> <a href="#" > <img src="images/3month.png" alt="www.satta-king.in" width="150" height="30" /></a></center>    
    <style>
        .month_result_table {
            border:1px thin; text-align:center;
        }
        .month_result_table thead tr th {border-color: #000;
    background-color: red;
    color: white;
    font-size: 12px;
    font-weight: bold;border: solid 1px black; 
    
    
        }
        .month_result_table thead tr th:nth-child(1) {border-color: #000;
    background-color: red;
    color: white;
    font-size: 12px;
    font-weight: bold;border: solid 1px black; 
    
    
        }
        .month_result_table tr td:nth-child(n+1) {
            border-color:#000 solid 1px; 
            background-color:white; 
            color:red; 
            font-size:32px; 
            font-weight:bold; 
            }
            .month_result_table tr td {
            border: solid 1px #bbbbbb; 
            }
            .month_result_table tr td:nth-child(1) {
            
            background-color: white; 
            color:#B90621; 
            font-size:11px; 
            font-weight:bold; 
            
            }
            h2{
                color: white;
    font-size: 38px;
    padding: 0px;
    margin: 0px;
            }
           .mydatecss{
               background-color:#ffddff;
           }
    </style> 


<table width="100%" class="month_result_table rtable"  border="0" cellspacing="0" cellpadding="0" class="dashed">
      


<thead>
        <tr>
        <th style="font-size:8px">Date</th>
        		<th style="font-size:8px; text-align:center; padding:0px 4px 0px 4px">FARIDABAD </th>		<th style="font-size:8px; text-align:center; padding:0px 4px 0px 4px">GHAZIABAD</th>		<th style="font-size:8px; text-align:center; padding:0px 4px 0px 4px">GALI</th>		<th style="font-size:8px; text-align:center; padding:0px 4px 0px 4px">DESAWAR</th>		<th style="font-size:8px; text-align:center; padding:0px 4px 0px 4px">DELHI KING</th>		<th style="font-size:8px; text-align:center; padding:0px 4px 0px 4px">NEW DELHI</th>		<th style="font-size:8px; text-align:center; padding:0px 4px 0px 4px">MUMBAI</th>        
        </tr>
    </thead>
	<tbody>

<tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">01-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      49</td>
                  					  <td style="font-size:12px">
                      85</td>
                  					  <td style="font-size:12px">
                      61</td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      95</td>
                  					  <td style="font-size:12px">
                      03</td>
                  					  <td style="font-size:12px">
                      62</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">02-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      75</td>
                  					  <td style="font-size:12px">
                      90</td>
                  					  <td style="font-size:12px">
                      19</td>
                  					  <td style="font-size:12px">
                      09</td>
                  					  <td style="font-size:12px">
                      86</td>
                  					  <td style="font-size:12px">
                      90</td>
                  					  <td style="font-size:12px">
                      59</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">03-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      29</td>
                  					  <td style="font-size:12px">
                      91</td>
                  					  <td style="font-size:12px">
                      87</td>
                  					  <td style="font-size:12px">
                      28</td>
                  					  <td style="font-size:12px">
                      98</td>
                  					  <td style="font-size:12px">
                      39</td>
                  					  <td style="font-size:12px">
                      91</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">04-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      75</td>
                  					  <td style="font-size:12px">
                      97</td>
                  					  <td style="font-size:12px">
                      87R</td>
                  					  <td style="font-size:12px">
                      18</td>
                  					  <td style="font-size:12px">
                      89</td>
                  					  <td style="font-size:12px">
                      29</td>
                  					  <td style="font-size:12px">
                      92</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">05-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      89</td>
                  					  <td style="font-size:12px">
                      90</td>
                  					  <td style="font-size:12px">
                      34</td>
                  					  <td style="font-size:12px">
                      06</td>
                  					  <td style="font-size:12px">
                      77</td>
                  					  <td style="font-size:12px">
                      16</td>
                  					  <td style="font-size:12px">
                      74</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">06-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      93</td>
                  					  <td style="font-size:12px">
                      23</td>
                  					  <td style="font-size:12px">
                      50</td>
                  					  <td style="font-size:12px">
                      28</td>
                  					  <td style="font-size:12px">
                      16</td>
                  					  <td style="font-size:12px">
                      34</td>
                  					  <td style="font-size:12px">
                      91</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">07-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      72</td>
                  					  <td style="font-size:12px">
                      93</td>
                  					  <td style="font-size:12px">
                      95</td>
                  					  <td style="font-size:12px">
                      56</td>
                  					  <td style="font-size:12px">
                      13</td>
                  					  <td style="font-size:12px">
                      68</td>
                  					  <td style="font-size:12px">
                      13</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">08-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      31</td>
                  					  <td style="font-size:12px">
                      30</td>
                  					  <td style="font-size:12px">
                      10</td>
                  					  <td style="font-size:12px">
                      39</td>
                  					  <td style="font-size:12px">
                      91</td>
                  					  <td style="font-size:12px">
                      31</td>
                  					  <td style="font-size:12px">
                      73</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">09-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      84</td>
                  					  <td style="font-size:12px">
                      63</td>
                  					  <td style="font-size:12px">
                      86</td>
                  					  <td style="font-size:12px">
                      41</td>
                  					  <td style="font-size:12px">
                      33</td>
                  					  <td style="font-size:12px">
                      86</td>
                  					  <td style="font-size:12px">
                      40</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">10-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      25</td>
                  					  <td style="font-size:12px">
                      20</td>
                  					  <td style="font-size:12px">
                      70</td>
                  					  <td style="font-size:12px">
                      10</td>
                  					  <td style="font-size:12px">
                      60</td>
                  					  <td style="font-size:12px">
                      13</td>
                  					  <td style="font-size:12px">
                      94</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">11-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      63</td>
                  					  <td style="font-size:12px">
                      16</td>
                  					  <td style="font-size:12px">
                      19</td>
                  					  <td style="font-size:12px">
                      43</td>
                  					  <td style="font-size:12px">
                      40</td>
                  					  <td style="font-size:12px">
                      22</td>
                  					  <td style="font-size:12px">
                      40</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">12-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      51</td>
                  					  <td style="font-size:12px">
                      45</td>
                  					  <td style="font-size:12px">
                      79</td>
                  					  <td style="font-size:12px">
                      43R</td>
                  					  <td style="font-size:12px">
                      26</td>
                  					  <td style="font-size:12px">
                      00</td>
                  					  <td style="font-size:12px">
                      64</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">13-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      33</td>
                  					  <td style="font-size:12px">
                      04</td>
                  					  <td style="font-size:12px">
                      05</td>
                  					  <td style="font-size:12px">
                      64</td>
                  					  <td style="font-size:12px">
                      02</td>
                  					  <td style="font-size:12px">
                      44</td>
                  					  <td style="font-size:12px">
                      52</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">14-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      45</td>
                  					  <td style="font-size:12px">
                      06</td>
                  					  <td style="font-size:12px">
                      52</td>
                  					  <td style="font-size:12px">
                      84</td>
                  					  <td style="font-size:12px">
                      07</td>
                  					  <td style="font-size:12px">
                      43</td>
                  					  <td style="font-size:12px">
                      05</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">15-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      86</td>
                  					  <td style="font-size:12px">
                      52</td>
                  					  <td style="font-size:12px">
                      93</td>
                  					  <td style="font-size:12px">
                      24</td>
                  					  <td style="font-size:12px">
                      44</td>
                  					  <td style="font-size:12px">
                      60</td>
                  					  <td style="font-size:12px">
                      16</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">16-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      99</td>
                  					  <td style="font-size:12px">
                      25</td>
                  					  <td style="font-size:12px">
                      88</td>
                  					  <td style="font-size:12px">
                      51</td>
                  					  <td style="font-size:12px">
                      05</td>
                  					  <td style="font-size:12px">
                      40</td>
                  					  <td style="font-size:12px">
                      87</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">17-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      03</td>
                  					  <td style="font-size:12px">
                      95</td>
                  					  <td style="font-size:12px">
                      14</td>
                  					  <td style="font-size:12px">
                      41</td>
                  					  <td style="font-size:12px">
                      95</td>
                  					  <td style="font-size:12px">
                      87</td>
                  					  <td style="font-size:12px">
                      53</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">18-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      37</td>
                  					  <td style="font-size:12px">
                      33</td>
                  					  <td style="font-size:12px">
                      52</td>
                  					  <td style="font-size:12px">
                      84</td>
                  					  <td style="font-size:12px">
                      29</td>
                  					  <td style="font-size:12px">
                      03</td>
                  					  <td style="font-size:12px">
                      13</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">19-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      25</td>
                  					  <td style="font-size:12px">
                      13</td>
                  					  <td style="font-size:12px">
                      02</td>
                  					  <td style="font-size:12px">
                      78</td>
                  					  <td style="font-size:12px">
                      24</td>
                  					  <td style="font-size:12px">
                      49</td>
                  					  <td style="font-size:12px">
                      47</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">20-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      52</td>
                  					  <td style="font-size:12px">
                      38</td>
                  					  <td style="font-size:12px">
                      87</td>
                  					  <td style="font-size:12px">
                      04</td>
                  					  <td style="font-size:12px">
                      23</td>
                  					  <td style="font-size:12px">
                      63</td>
                  					  <td style="font-size:12px">
                      03</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">21-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      46</td>
                  					  <td style="font-size:12px">
                      15</td>
                  					  <td style="font-size:12px">
                      72</td>
                  					  <td style="font-size:12px">
                      56</td>
                  					  <td style="font-size:12px">
                      14</td>
                  					  <td style="font-size:12px">
                      56</td>
                  					  <td style="font-size:12px">
                      68</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">22-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      82</td>
                  					  <td style="font-size:12px">
                      38</td>
                  					  <td style="font-size:12px">
                      53</td>
                  					  <td style="font-size:12px">
                      72</td>
                  					  <td style="font-size:12px">
                      26</td>
                  					  <td style="font-size:12px">
                      37</td>
                  					  <td style="font-size:12px">
                      61</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">23-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      40</td>
                  					  <td style="font-size:12px">
                      37</td>
                  					  <td style="font-size:12px">
                      82</td>
                  					  <td style="font-size:12px">
                      16</td>
                  					  <td style="font-size:12px">
                      74</td>
                  					  <td style="font-size:12px">
                      00</td>
                  					  <td style="font-size:12px">
                      18</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">24-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      78</td>
                  					  <td style="font-size:12px">
                      20</td>
                  					  <td style="font-size:12px">
                      97</td>
                  					  <td style="font-size:12px">
                      78</td>
                  					  <td style="font-size:12px">
                      84</td>
                  					  <td style="font-size:12px">
                      43</td>
                  					  <td style="font-size:12px">
                      47</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">25-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      46</td>
                  					  <td style="font-size:12px">
                      12</td>
                  					  <td style="font-size:12px">
                      66</td>
                  					  <td style="font-size:12px">
                      62</td>
                  					  <td style="font-size:12px">
                      76</td>
                  					  <td style="font-size:12px">
                      04</td>
                  					  <td style="font-size:12px">
                      22</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">26-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      31</td>
                  					  <td style="font-size:12px">
                      77</td>
                  					  <td style="font-size:12px">
                      87</td>
                  					  <td style="font-size:12px">
                      46</td>
                  					  <td style="font-size:12px">
                      01</td>
                  					  <td style="font-size:12px">
                      61</td>
                  					  <td style="font-size:12px">
                      14</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">27-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      60</td>
                  					  <td style="font-size:12px">
                      96</td>
                  					  <td style="font-size:12px">
                      61</td>
                  					  <td style="font-size:12px">
                      50</td>
                  					  <td style="font-size:12px">
                      12</td>
                  					  <td style="font-size:12px">
                      02</td>
                  					  <td style="font-size:12px">
                      79</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">28-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      96</td>
                  					  <td style="font-size:12px">
                      44</td>
                  					  <td style="font-size:12px">
                      60</td>
                  					  <td style="font-size:12px">
                      68</td>
                  					  <td style="font-size:12px">
                      21</td>
                  					  <td style="font-size:12px">
                      06</td>
                  					  <td style="font-size:12px">
                      62</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">29-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      60</td>
                  					  <td style="font-size:12px">
                      93</td>
                  					  <td style="font-size:12px">
                      75</td>
                  					  <td style="font-size:12px">
                      06</td>
                  					  <td style="font-size:12px">
                      96</td>
                  					  <td style="font-size:12px">
                      62</td>
                  					  <td style="font-size:12px">
                      59</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">30-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      47</td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  
        </tr> </tbody>
  </table>

<table width="100%" class="month_result_table rtable"  border="0" cellspacing="0" cellpadding="0" class="dashed">
      


<thead>
        <tr>
        <th style="font-size:8px">Date</th>
        		<th style="font-size:8px; text-align:center; padding:0px 5px 0px 5px">DL-NCR</th>		<th style="font-size:8px; text-align:center; padding:0px 5px 0px 5px">GALI GOLD NEW</th>		<th style="font-size:8px; text-align:center; padding:0px 5px 0px 5px">KUBER</th>		<th style="font-size:8px; text-align:center; padding:0px 5px 0px 5px">SUPER GURGAON</th>		<th style="font-size:8px; text-align:center; padding:0px 5px 0px 5px">KAVERI</th>		<th style="font-size:8px; text-align:center; padding:0px 5px 0px 5px">TULSI</th>		<th style="font-size:8px; text-align:center; padding:0px 5px 0px 5px">SHIV HARI</th>        
        </tr>
    </thead>
	<tbody>

<tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">01-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      82</td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      23</td>
                  					  <td style="font-size:12px">
                      34</td>
                  					  <td style="font-size:12px">
                      56</td>
                  					  <td style="font-size:12px">
                      65</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">02-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      04</td>
                  					  <td style="font-size:12px">
                      76</td>
                  					  <td style="font-size:12px">
                      50</td>
                  					  <td style="font-size:12px">
                      54</td>
                  					  <td style="font-size:12px">
                      29</td>
                  					  <td style="font-size:12px">
                      78</td>
                  					  <td style="font-size:12px">
                      42</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">03-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      98</td>
                  					  <td style="font-size:12px">
                      84</td>
                  					  <td style="font-size:12px">
                      97</td>
                  					  <td style="font-size:12px">
                      57</td>
                  					  <td style="font-size:12px">
                      55</td>
                  					  <td style="font-size:12px">
                      12</td>
                  					  <td style="font-size:12px">
                      19</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">04-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      18</td>
                  					  <td style="font-size:12px">
                      68</td>
                  					  <td style="font-size:12px">
                      44</td>
                  					  <td style="font-size:12px">
                      06</td>
                  					  <td style="font-size:12px">
                      88</td>
                  					  <td style="font-size:12px">
                      32</td>
                  					  <td style="font-size:12px">
                      57</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">05-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      23</td>
                  					  <td style="font-size:12px">
                      26</td>
                  					  <td style="font-size:12px">
                      37</td>
                  					  <td style="font-size:12px">
                      88</td>
                  					  <td style="font-size:12px">
                      34</td>
                  					  <td style="font-size:12px">
                      51</td>
                  					  <td style="font-size:12px">
                      11</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">06-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      97</td>
                  					  <td style="font-size:12px">
                      70</td>
                  					  <td style="font-size:12px">
                      41</td>
                  					  <td style="font-size:12px">
                      51</td>
                  					  <td style="font-size:12px">
                      24</td>
                  					  <td style="font-size:12px">
                      43</td>
                  					  <td style="font-size:12px">
                      27</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">07-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      51</td>
                  					  <td style="font-size:12px">
                      63</td>
                  					  <td style="font-size:12px">
                      35</td>
                  					  <td style="font-size:12px">
                      65</td>
                  					  <td style="font-size:12px">
                      49</td>
                  					  <td style="font-size:12px">
                      80</td>
                  					  <td style="font-size:12px">
                      21</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">08-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      27</td>
                  					  <td style="font-size:12px">
                      61</td>
                  					  <td style="font-size:12px">
                      48</td>
                  					  <td style="font-size:12px">
                      12</td>
                  					  <td style="font-size:12px">
                      09</td>
                  					  <td style="font-size:12px">
                      37</td>
                  					  <td style="font-size:12px">
                      57</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">09-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      00</td>
                  					  <td style="font-size:12px">
                      91</td>
                  					  <td style="font-size:12px">
                      28</td>
                  					  <td style="font-size:12px">
                      14</td>
                  					  <td style="font-size:12px">
                      17</td>
                  					  <td style="font-size:12px">
                      60</td>
                  					  <td style="font-size:12px">
                      44</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">10-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      69</td>
                  					  <td style="font-size:12px">
                      72</td>
                  					  <td style="font-size:12px">
                      20</td>
                  					  <td style="font-size:12px">
                      58</td>
                  					  <td style="font-size:12px">
                      30</td>
                  					  <td style="font-size:12px">
                      73</td>
                  					  <td style="font-size:12px">
                      28</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">11-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      75</td>
                  					  <td style="font-size:12px">
                      70</td>
                  					  <td style="font-size:12px">
                      47</td>
                  					  <td style="font-size:12px">
                      61</td>
                  					  <td style="font-size:12px">
                      28</td>
                  					  <td style="font-size:12px">
                      14</td>
                  					  <td style="font-size:12px">
                      18</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">12-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      19</td>
                  					  <td style="font-size:12px">
                      02</td>
                  					  <td style="font-size:12px">
                      42</td>
                  					  <td style="font-size:12px">
                      34</td>
                  					  <td style="font-size:12px">
                      94</td>
                  					  <td style="font-size:12px">
                      37</td>
                  					  <td style="font-size:12px">
                      68</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">13-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      64</td>
                  					  <td style="font-size:12px">
                      30</td>
                  					  <td style="font-size:12px">
                      78</td>
                  					  <td style="font-size:12px">
                      30</td>
                  					  <td style="font-size:12px">
                      04</td>
                  					  <td style="font-size:12px">
                      26</td>
                  					  <td style="font-size:12px">
                      31</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">14-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      84</td>
                  					  <td style="font-size:12px">
                      96</td>
                  					  <td style="font-size:12px">
                      07</td>
                  					  <td style="font-size:12px">
                      57</td>
                  					  <td style="font-size:12px">
                      96</td>
                  					  <td style="font-size:12px">
                      71</td>
                  					  <td style="font-size:12px">
                      56</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">15-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      74</td>
                  					  <td style="font-size:12px">
                      58</td>
                  					  <td style="font-size:12px">
                      09</td>
                  					  <td style="font-size:12px">
                      78</td>
                  					  <td style="font-size:12px">
                      38</td>
                  					  <td style="font-size:12px">
                      21</td>
                  					  <td style="font-size:12px">
                      14</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">16-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      01</td>
                  					  <td style="font-size:12px">
                      70</td>
                  					  <td style="font-size:12px">
                      21</td>
                  					  <td style="font-size:12px">
                      13</td>
                  					  <td style="font-size:12px">
                      54</td>
                  					  <td style="font-size:12px">
                      68</td>
                  					  <td style="font-size:12px">
                      94</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">17-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      41</td>
                  					  <td style="font-size:12px">
                      47</td>
                  					  <td style="font-size:12px">
                      84</td>
                  					  <td style="font-size:12px">
                      72</td>
                  					  <td style="font-size:12px">
                      71</td>
                  					  <td style="font-size:12px">
                      04</td>
                  					  <td style="font-size:12px">
                      91</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">18-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      88</td>
                  					  <td style="font-size:12px">
                      86</td>
                  					  <td style="font-size:12px">
                      14</td>
                  					  <td style="font-size:12px">
                      53</td>
                  					  <td style="font-size:12px">
                      75</td>
                  					  <td style="font-size:12px">
                      77</td>
                  					  <td style="font-size:12px">
                      53</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">19-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      36</td>
                  					  <td style="font-size:12px">
                      08</td>
                  					  <td style="font-size:12px">
                      64</td>
                  					  <td style="font-size:12px">
                      99</td>
                  					  <td style="font-size:12px">
                      95</td>
                  					  <td style="font-size:12px">
                      38</td>
                  					  <td style="font-size:12px">
                      86</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">20-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      04</td>
                  					  <td style="font-size:12px">
                      47</td>
                  					  <td style="font-size:12px">
                      18</td>
                  					  <td style="font-size:12px">
                      75</td>
                  					  <td style="font-size:12px">
                      08</td>
                  					  <td style="font-size:12px">
                      95</td>
                  					  <td style="font-size:12px">
                      13</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">21-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      15</td>
                  					  <td style="font-size:12px">
                      01</td>
                  					  <td style="font-size:12px">
                      97</td>
                  					  <td style="font-size:12px">
                      45</td>
                  					  <td style="font-size:12px">
                      06</td>
                  					  <td style="font-size:12px">
                      65</td>
                  					  <td style="font-size:12px">
                      37</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">22-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      03</td>
                  					  <td style="font-size:12px">
                      05</td>
                  					  <td style="font-size:12px">
                      52</td>
                  					  <td style="font-size:12px">
                      17</td>
                  					  <td style="font-size:12px">
                      23</td>
                  					  <td style="font-size:12px">
                      22</td>
                  					  <td style="font-size:12px">
                      20</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">23-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      77</td>
                  					  <td style="font-size:12px">
                      28</td>
                  					  <td style="font-size:12px">
                      91</td>
                  					  <td style="font-size:12px">
                      48</td>
                  					  <td style="font-size:12px">
                      11</td>
                  					  <td style="font-size:12px">
                      43</td>
                  					  <td style="font-size:12px">
                      28</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">24-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      70</td>
                  					  <td style="font-size:12px">
                      76</td>
                  					  <td style="font-size:12px">
                      15</td>
                  					  <td style="font-size:12px">
                      81</td>
                  					  <td style="font-size:12px">
                      12</td>
                  					  <td style="font-size:12px">
                      43</td>
                  					  <td style="font-size:12px">
                      42</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">25-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      63</td>
                  					  <td style="font-size:12px">
                      29</td>
                  					  <td style="font-size:12px">
                      89</td>
                  					  <td style="font-size:12px">
                      46</td>
                  					  <td style="font-size:12px">
                      15</td>
                  					  <td style="font-size:12px">
                      14</td>
                  					  <td style="font-size:12px">
                      64</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">26-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      96</td>
                  					  <td style="font-size:12px">
                      12</td>
                  					  <td style="font-size:12px">
                      31</td>
                  					  <td style="font-size:12px">
                      88</td>
                  					  <td style="font-size:12px">
                      87</td>
                  					  <td style="font-size:12px">
                      03</td>
                  					  <td style="font-size:12px">
                      04</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">27-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      59</td>
                  					  <td style="font-size:12px">
                      93</td>
                  					  <td style="font-size:12px">
                      97</td>
                  					  <td style="font-size:12px">
                      52</td>
                  					  <td style="font-size:12px">
                      36</td>
                  					  <td style="font-size:12px">
                      11</td>
                  					  <td style="font-size:12px">
                      53</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">28-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      68</td>
                  					  <td style="font-size:12px">
                      14</td>
                  					  <td style="font-size:12px">
                      11</td>
                  					  <td style="font-size:12px">
                      60</td>
                  					  <td style="font-size:12px">
                      63</td>
                  					  <td style="font-size:12px">
                      19</td>
                  					  <td style="font-size:12px">
                      80</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">29-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      79</td>
                  					  <td style="font-size:12px">
                      30</td>
                  					  <td style="font-size:12px">
                      67</td>
                  					  <td style="font-size:12px">
                      76</td>
                  					  <td style="font-size:12px">
                      52</td>
                  					  <td style="font-size:12px">
                      45</td>
                  					  <td style="font-size:12px">
                      38</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">30-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      62</td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  
        </tr> </tbody>
  </table>
  
  
 <table width="100%" class="month_result_table rtable"  border="0" cellspacing="0" cellpadding="0" class="dashed">
      


<thead>
        <tr>
        <th style="font-size:8px">Date</th>
        		<th style="font-size:8px; text-align:center; padding:1px 20px 1px 20px">KALYAN DELHI</th>		<th style="font-size:8px; text-align:center; padding:1px 20px 1px 20px">RAWALPINDI</th>		<th style="font-size:8px; text-align:center; padding:1px 20px 1px 20px">JAIPUR</th>        
        </tr>
    </thead>
	<tbody>

<tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">01-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      27</td>
                  					  <td style="font-size:12px">
                      10</td>
                  					  <td style="font-size:12px">
                      05</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">02-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      02</td>
                  					  <td style="font-size:12px">
                      85</td>
                  					  <td style="font-size:12px">
                      09</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">03-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      58</td>
                  					  <td style="font-size:12px">
                      41</td>
                  					  <td style="font-size:12px">
                      21</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">04-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      76</td>
                  					  <td style="font-size:12px">
                      53</td>
                  					  <td style="font-size:12px">
                      27</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">05-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      49</td>
                  					  <td style="font-size:12px">
                      30</td>
                  					  <td style="font-size:12px">
                      02</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">06-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      53</td>
                  					  <td style="font-size:12px">
                      56</td>
                  					  <td style="font-size:12px">
                      15</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">07-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      77</td>
                  					  <td style="font-size:12px">
                      33</td>
                  					  <td style="font-size:12px">
                      22</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">08-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      25</td>
                  					  <td style="font-size:12px">
                      51</td>
                  					  <td style="font-size:12px">
                      72</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">09-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      04</td>
                  					  <td style="font-size:12px">
                      23</td>
                  					  <td style="font-size:12px">
                      14</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">10-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      82</td>
                  					  <td style="font-size:12px">
                      50</td>
                  					  <td style="font-size:12px">
                      64</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">11-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      21</td>
                  					  <td style="font-size:12px">
                      24</td>
                  					  <td style="font-size:12px">
                      00</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">12-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      91</td>
                  					  <td style="font-size:12px">
                      01</td>
                  					  <td style="font-size:12px">
                      12</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">13-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      68</td>
                  					  <td style="font-size:12px">
                      37</td>
                  					  <td style="font-size:12px">
                      41</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">14-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      11</td>
                  					  <td style="font-size:12px">
                      40</td>
                  					  <td style="font-size:12px">
                      31</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">15-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      87</td>
                  					  <td style="font-size:12px">
                      85</td>
                  					  <td style="font-size:12px">
                      33</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">16-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      46</td>
                  					  <td style="font-size:12px">
                      69</td>
                  					  <td style="font-size:12px">
                      17</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">17-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      57</td>
                  					  <td style="font-size:12px">
                      00</td>
                  					  <td style="font-size:12px">
                      99</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">18-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      31</td>
                  					  <td style="font-size:12px">
                      42</td>
                  					  <td style="font-size:12px">
                      24</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">19-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      50</td>
                  					  <td style="font-size:12px">
                      04</td>
                  					  <td style="font-size:12px">
                      28</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">20-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      19</td>
                  					  <td style="font-size:12px">
                      23</td>
                  					  <td style="font-size:12px">
                      76</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">21-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      64</td>
                  					  <td style="font-size:12px">
                      56</td>
                  					  <td style="font-size:12px">
                      26</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">22-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      72</td>
                  					  <td style="font-size:12px">
                      28</td>
                  					  <td style="font-size:12px">
                      38</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">23-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      39</td>
                  					  <td style="font-size:12px">
                      18</td>
                  					  <td style="font-size:12px">
                      05</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">24-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      94</td>
                  					  <td style="font-size:12px">
                      50</td>
                  					  <td style="font-size:12px">
                      13</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">25-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      11</td>
                  					  <td style="font-size:12px">
                      17</td>
                  					  <td style="font-size:12px">
                      46</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">26-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      74</td>
                  					  <td style="font-size:12px">
                      37</td>
                  					  <td style="font-size:12px">
                      73</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">27-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      54</td>
                  					  <td style="font-size:12px">
                      42</td>
                  					  <td style="font-size:12px">
                      02</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">28-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      88</td>
                  					  <td style="font-size:12px">
                      16</td>
                  					  <td style="font-size:12px">
                      54</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">29-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      17</td>
                  					  <td style="font-size:12px">
                      95</td>
                  					  <td style="font-size:12px">
                      96</td>
                  
        </tr><tr>					  
					  <tr> <td style="font-size:6px" class="mydatecss">30-<br>06-<br> 20</td>
					  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  					  <td style="font-size:12px">
                      </td>
                  
        </tr> </tbody>
  </table> 



	






<table border="1" align="center" width="100%">
   <td align="center" width="50%" class="ONLINE">
      <a title="satta king" href="https://www.satta-kingz.in/">
      <font color="#ffffff">Satta king</font></a> 
   </td>
   <td align="center" width="100%" class="ONLINE">
      <a title="satta king" href="https://www.satta-kingz.in/">
      <font color="#ffffff">Satta King</font></a> 
   </td>
   </a> </td>
</table>

<div class="cht_link"> 
      <a href="satta-king-game-record-chart.php" >SATTA KING RECORDS CHART </a>
   </div>
 <div class="cht_link"> 
      <a href="satta-king-game-record-chart.php" >D-D GALI DISAWAR RECORD CHART</a>
   </div>  
 <div class="cht_link"> 
      <a title="desawar satta record chart 2020" href="desawar-satta-record-chart-2020.php" >DESAWAR RECORD CHART 2020</a>
   </div>    
<div class="cht_link"> 
      <a title="gali satta record chart 2020" href="gali-satta-record-chart-2020.php" > GALI SATTA RECORD CHART 2020  </a>
   </div> 
<div class="cht_link"> 
      <a title="faridabad satta record chart 2020" href="faridabad-satta-record-chart-2020.php" >FARIDABAD SATTA RECORD CHART 2020</a>
   </div>       
<div class="cht_link"> 
      <a title="ghaziabad satta record chart 2020" href="ghaziabad-satta-record-chart-2020.php" >GHAZIABAD SATTA RECORD CHART 2020</a>
   </div>       
 <!--<div class="cht_link"> 
      <a title="taj satta record chart 2020" href="taj-satta-record-chart-2020.php" >TAJ SATTA RECORD CHART 2020</a>
   </div>
   <div class="cht_link"> 
      <a title="UP satta record chart 2020" href="UP-satta-record-chart-2020.php" >UP SATTA RECORD CHART 2020</a>
   </div>
  <div class="cht_link"> 
      <a title="Shri ganesh satta record chart 2020" href="shri-ganesh-satta-record-chart-2020.php" >SHRI GANESH SATTA RECORD CHART 2020</a>
   </div> 
<div class="cht_link"> 
      <a title="delhi King satta record chart 2020" href="delhi-king-satta-record-chart-2020.php" >DELHI KING SATTA RECORD CHART 2020</a>
   </div>   -->         
<div class="cht_link"> 
      <a title="satta king fast result" href="satta-king-fast-result.php" > SATTA KING FAST RESULT </a>
   </div>            

      




<div style="background-color: lightyellow; font-weight: bold; border-width: 3px; border-color:red; border-style: outset; padding: 5px; border-radius: 10px; text-align: center;">
    <font style="color:#000; font-size:16px">Www.satta-kingz.in</font><br>
<font style="color:red; font-size:15px"> अपनी सट्टा मटका गेम का रिज़ल्ट हमारी वेबसाइट मे डलवाना हो या अपनी गेम बेच कर पैसा कमाना चाहते हो तो कॉल करे </font>
<br><span style="color: brown">*****************</span><br>
<img style="width:30px" src="images/call.png" alt="satta king com satta com सट्टा नंबर सट्टा-किंग सट्टाकिंग सट्टा रिज़ल्ट सट्टा गेम satta king result, satta king online,today satta result, satta.com">
<br><font style="color:blue; font-size:15px">MAX MILLER <br> Phone No.7042553480</font><br>


<a style="font-size:12px" href="tel:+917042553480"><button>CLICK FOR CALL</button></a>
        <br>
		<p style="color:brown; font-size:14px">AVAILABLE ON WHATS APP</p></div>






<div class="footer">
<p>SATTA KINGZ &copy; 2020</p>
<a href="contact.php">Contact</a> | <a href="disclaimer.php">Disclaimer</a> | <a href="sitemap.xml">Sitemap</a>
<script src="//code.jivosite.com/widget/O0KBC3zD5D" async></script>
</div>


      </body>
</html>
